/*
Template Name: Admiria - Admin & Dashboard Template
Author: Themesbrand
Website: https://themesbrand.com/
Contact: themesbrand@gmail.com
File: Ecommerce Init Js File
*/

$(document).ready(function() {
    $('#datatable').DataTable();
    $(".dataTables_length select").addClass('form-select form-select-sm');
} );

