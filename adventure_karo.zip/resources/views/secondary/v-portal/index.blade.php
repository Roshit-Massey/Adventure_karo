@extends('secondary.layouts.master_new')
@section('title', 'Vendor Dashboard')
@section('container') 
<div class="main-content" id="result">
    <div class="page-content">
        <div class="container-fluid">
            Dashboard
        </div>
    </div>
</div>
@endsection