<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <script>document.write(new Date().getFullYear())</script> © Adventure Karo.
            </div>
            <div class="col-sm-6">
                <div class="text-sm-end d-none d-sm-block">
                    Version 1.0
                </div>
            </div>
        </div>
    </div>
</footer><?php /**PATH D:\xmapp\htdocs\adventure_karo\resources\views/secondary/layouts/footer_new.blade.php ENDPATH**/ ?>