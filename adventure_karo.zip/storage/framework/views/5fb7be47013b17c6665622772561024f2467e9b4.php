<?php $__env->startSection('title', 'All Classes'); ?>
<?php $__env->startSection('container'); ?> 
<div class="main-content" id="result">
    <div class="page-content">
        <div class="container-fluid">
            Dashboard
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('secondary.layouts.master_new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xmapp\htdocs\adventure_karo\resources\views/secondary/dashboard/index.blade.php ENDPATH**/ ?>