<?php $__env->startSection('title', 'All Activities'); ?>
<?php $__env->startSection('container'); ?> 
<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" type="text/css" href="/secondary/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
<link href="/secondary/assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css" rel="stylesheet"  type="text/css">
<?php $__env->stopSection(); ?>
<div class="main-content" id="result">
    <div class="page-content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">

                            <h4 class="card-title">All Activities</h4>
                            <table id="datatable" class="table table-bordered dt-responsive"
                                style="border-collapse: collapse; border-spacing: 0; width: 100%;">

                                <thead>
                                    <tr>
                                        <th>Sr. No.</th>
                                        <!-- <th>Image</th> -->
                                        <th>Name</th>
                                        <th>Info</th>
                                        <th>Created At</th>
                                        <th>Updated At</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                                </tbody>
                            </table>

                        </div>
                    </div>
                </div> <!-- end col -->
            </div> <!-- end row -->

        </div> <!-- container-fluid -->
    </div>
</div>
<!-- End Page-content -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="/secondary/assets/libs/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="/secondary/assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="/secondary/assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>
<script src="/secondary/js/app/list-activity.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('secondary.layouts.master_new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xmapp\htdocs\adventure_karo\resources\views/secondary/activity/index.blade.php ENDPATH**/ ?>