<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description">
    <meta content="Themesbrand" name="author">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <script src="/js/chat-app.js" defer></script>
    <link href="/css/chat-app.css" rel="stylesheet">
    <link rel="shortcut icon" href="/secondary/assets/images/favicon.ico">
    <link href="/secondary/assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css">
    <link href="/secondary/assets/css/icons.min.css" rel="stylesheet" type="text/css">
    <link href="/secondary/assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css">
    <link href="/secondary/assets/css/custom.css" rel="stylesheet" type="text/css" />
    <link href="/secondary/assets/libs/select2/css/select2.min.css" rel="stylesheet" type="text/css">
    <link href="/secondary/assets/css/new-custom-style.css" rel="stylesheet" type="text/css" />
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body data-sidebar="dark">
    <div id="preloader"><div id="status"><div class="spinner"></div></div></div>
    <div id="layout-wrapper">
        <?php echo $__env->make('secondary.layouts.header_new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('secondary.layouts.left-navbar_new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('container'); ?>
        <?php echo $__env->make('secondary.layouts.footer_new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div> 
    <div class="rightbar-overlay"></div>
    <script src="/secondary/assets/libs/jquery/jquery.min.js"></script>
    <script src="/secondary/assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="/secondary/assets/libs/metismenu/metisMenu.min.js"></script>
    <script src="/secondary/assets/libs/simplebar/simplebar.min.js"></script>
    <script src="/secondary/assets/libs/node-waves/waves.min.js"></script>
    <script src="https://maps.google.com/maps/api/js?key=AIzaSyCtSAR45TFgZjOs4nBFFZnII-6mMHLfSYI"></script>
    <script src="/secondary/assets/libs/admin-resources/bootstrap-filestyle/bootstrap-filestyle.min.js"></script>
    <script src="/secondary/assets/js/app.js"></script>
    <script src="/secondary/assets/libs/select2/js/select2.min.js"></script>
    <script src="/secondary/assets/js/pages/form-advanced.init.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="/secondary/sloop.js"> </script>
    <script src="/app.js"> </script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html><?php /**PATH D:\xmapp\htdocs\adventure_karo\resources\views/secondary/layouts/master_new.blade.php ENDPATH**/ ?>